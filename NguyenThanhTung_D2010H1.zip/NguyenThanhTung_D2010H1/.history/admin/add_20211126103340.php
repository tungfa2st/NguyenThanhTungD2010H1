<?php
require "config.php";
require "models/db.php";
require "models/products.php";
require "models/manufactures.php";
require "models/protype.php";
$product = new Product;
$manu = new Manufactures;
$type = new Protype;
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $manu_id = $_POST['manu'];
    $type_id = $_POST['type'];
    $price = $_POST['price'];
    $desc = $_POST['desc'];
    $image = $_FILES['image']['name'];
    // xu ly them
    $product->addProduct($name, $manu_id, $type_id, $price, $image, $desc);

    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    move_uploaded_file($_FILES["image"]["name"], $target_file);
}
