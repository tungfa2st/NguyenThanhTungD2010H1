<?php
require "config.php";
require "models/db.php";
require "models/products.php";
require "models/manufactures.php";
require "models/protype.php";
$product = new Product;
$manu = new Manufactures;
$type = new Protype;
if (isset($_GET['id'])) {
    # code...
    $product->delProduct($_GET['id']);
    header('location:products.php');
    if ($product->delProduct($_GET['id'])) {
        echo "them tc";
    } else {
        echo "khong";
    }
}
